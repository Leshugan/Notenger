package __PKG__;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

// Плитка в шторке: открывает быструю заметку (сохраняется в «Избранное»)
public class QuickNoteTileService extends TileService {

  @Override
  public void onStartListening() {
    super.onStartListening();
    try {
      Tile t = getQsTile();
      if (t != null) { t.setState(Tile.STATE_INACTIVE); t.updateTile(); }
    } catch (Exception ignored) {}
  }

  @Override
  public void onClick() {
    super.onClick();
    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("notenger://quicknote"));
    i.setClass(this, QuickNoteActivity.class);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    try {
      if (Build.VERSION.SDK_INT >= 34) {
        // На Android 14+ вариант с Intent бросает UnsupportedOperationException
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        startActivityAndCollapse(pi);
      } else {
        startActivityAndCollapse(i);
      }
    } catch (Exception e) {
      try { startActivity(i); } catch (Exception ignored) {}
    }
  }
}
