package __PKG__;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

// Трамплин быстрой заметки. Плитка и ярлык открывают ЕГО, а не MainActivity —
// root-интент задачи приложения всегда остаётся обычным, переигровок нет.
// На каждый клик генерится одноразовый nonce: prefs + extra интента; MainActivity
// откроет заметку только при совпадении пары.
public class QuickNoteActivity extends Activity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    try {
      long nonce = System.currentTimeMillis();
      MainActivity.putQuickNoteNonce(this, nonce);
      Intent i = new Intent(this, MainActivity.class);
      i.setAction(Intent.ACTION_MAIN);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(i);
    } catch (Exception e) {}
    finish();
  }
}
