package __PKG__;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

// Трамплин быстрой заметки. Плитка и ярлык открывают ЕГО, а не MainActivity —
// поэтому root-интент задачи приложения всегда остаётся обычным (MAIN), и
// пересоздание/повторный запуск иконкой никогда не «переигрывает» быструю заметку.
public class QuickNoteActivity extends Activity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    try { MainActivity.markQuickNote(this); } catch (Exception e) {}
    try {
      Intent i = new Intent(this, MainActivity.class);
      i.setAction(Intent.ACTION_MAIN);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
      startActivity(i);
    } catch (Exception e) {}
    finish();
  }
}
