package __PKG__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

// Виджет рабочего стола 1x1: одна иконка-карандаш, открывает быструю заметку
// через тот же трамплин, что плитка и ярлык.
public class QuickNoteWidget extends AppWidgetProvider {

  @Override
  public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
    for (int id : ids) {
      RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.qn_widget);
      Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("notenger://quicknote"), ctx, QuickNoteActivity.class);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      PendingIntent pi = PendingIntent.getActivity(ctx, 0, i,
          PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      rv.setOnClickPendingIntent(R.id.qn_widget_btn, pi);
      mgr.updateAppWidget(id, rv);
    }
  }
}
