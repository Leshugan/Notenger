package __PKG__;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.media.MediaRecorder;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import com.getcapacitor.BridgeActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.auth.GoogleAuthUtil;
import android.accounts.Account;
public class MainActivity extends BridgeActivity {
  private ValueCallback<Uri[]> filePathCallback;
  private Uri pendingCameraUri;
  private ActivityResultLauncher<Intent> fileChooserLauncher;
  private ActivityResultLauncher<Intent> saveFileLauncher;
  private ActivityResultLauncher<Intent> signInLauncher;
  private byte[] pendingSaveBytes;
  private MediaRecorder audioRec;
  private volatile boolean recStopRequested = false;
  private volatile boolean recActive = false;
  private String audioPath;
  private GoogleSignInClient gsiClient;
  private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Статус-бар и навбар — цвет фона приложения (#1A1410), светлые иконки (тёмная тема)
    try {
      Window w = getWindow();
      int bg = Color.parseColor("#1A1410");
      w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
      w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
      w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
      w.setStatusBarColor(bg);
      w.setNavigationBarColor(bg);
      View dv = w.getDecorView();
      int vis = dv.getSystemUiVisibility();
      // убрать флаги "светлых баров" → иконки останутся белыми на тёмном фоне
      vis &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
      if (Build.VERSION.SDK_INT >= 26) vis &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
      dv.setSystemUiVisibility(vis);
    } catch (Exception e) {}
    requestStartupPermissions();
    fileChooserLauncher = registerForActivityResult(
      new ActivityResultContracts.StartActivityForResult(),
      result -> {
        if (filePathCallback == null) return;
        Uri[] uris = null;
        if (result.getResultCode() == RESULT_OK) {
          Intent data = result.getData();
          if (data != null && data.getClipData() != null) {
            int n = data.getClipData().getItemCount();
            uris = new Uri[n];
            for (int i = 0; i < n; i++) uris[i] = data.getClipData().getItemAt(i).getUri();
          } else if (data != null && data.getData() != null) {
            uris = new Uri[]{ data.getData() };
          } else if (pendingCameraUri != null) {
            uris = new Uri[]{ pendingCameraUri };
          }
        }
        pendingCameraUri = null;
        filePathCallback.onReceiveValue(uris);
        filePathCallback = null;
      });
    saveFileLauncher = registerForActivityResult(
      new ActivityResultContracts.StartActivityForResult(),
      result -> {
        try {
          if (result.getResultCode() == RESULT_OK && result.getData() != null && pendingSaveBytes != null) {
            Uri uri = result.getData().getData();
            java.io.OutputStream os = getContentResolver().openOutputStream(uri);
            os.write(pendingSaveBytes); os.flush(); os.close();
            runOnUiThread(() -> android.widget.Toast.makeText(this, "Сохранено", android.widget.Toast.LENGTH_SHORT).show());
          }
        } catch (Exception e) {
          runOnUiThread(() -> android.widget.Toast.makeText(this, "Ошибка сохранения", android.widget.Toast.LENGTH_SHORT).show());
        }
        pendingSaveBytes = null;
      });
    // Google Sign-In с запросом scope для Drive appData
    GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
      .requestEmail()
      .requestScopes(new Scope(DRIVE_SCOPE))
      .build();
    gsiClient = GoogleSignIn.getClient(this, gso);
    signInLauncher = registerForActivityResult(
      new ActivityResultContracts.StartActivityForResult(),
      result -> {
        try {
          GoogleSignInAccount acct = GoogleSignIn.getSignedInAccountFromIntent(result.getData()).getResult();
          fetchTokenAsync(acct);
        } catch (Exception e) {
          resolveToken(null);
        }
      });
    // Настройки WebView для корректного захвата аудио/медиа
    try {
      android.webkit.WebSettings ws = this.bridge.getWebView().getSettings();
      ws.setMediaPlaybackRequiresUserGesture(false);
      ws.setJavaScriptEnabled(true);
      ws.setDomStorageEnabled(true);
    } catch (Exception ignore) {}
    // Нативная запись звука (минуя WebView/getUserMedia)
    this.bridge.getWebView().addJavascriptInterface(new Object(){
      @JavascriptInterface
      public void setBars(final String color, final boolean light){
        try{
          runOnUiThread(new Runnable(){ public void run(){
            try{
              Window w = getWindow();
              int c = Color.parseColor(color);
              w.setStatusBarColor(c);
              w.setNavigationBarColor(c);
              View dv = w.getDecorView();
              int vis = dv.getSystemUiVisibility();
              if(light){ vis |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; if(Build.VERSION.SDK_INT>=26) vis |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; }
              else { vis &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; if(Build.VERSION.SDK_INT>=26) vis &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; }
              dv.setSystemUiVisibility(vis);
            }catch(Exception e){}
          }});
        }catch(Exception e){}
      }
      @JavascriptInterface
      public boolean startRec(){
        try{
          stopRecInternal(false);
          recStopRequested = false;
          recActive = true;
          audioPath = getCacheDir().getAbsolutePath() + "/voice_" + System.currentTimeMillis() + ".m4a";
          audioRec = new MediaRecorder();
          audioRec.setAudioSource(MediaRecorder.AudioSource.MIC);
          audioRec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
          audioRec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
          audioRec.setAudioEncodingBitRate(64000);
          audioRec.setAudioSamplingRate(44100);
          audioRec.setOutputFile(audioPath);
          audioRec.prepare();
          audioRec.start();
          // если за время prepare/start пришёл запрос на отмену — немедленно останавливаем
          if(recStopRequested){ recStopRequested=false; stopRecInternal(false); return false; }
          return true;
        }catch(Exception e){ try{ if(audioRec!=null){audioRec.release();audioRec=null;} }catch(Exception ignore){} recActive=false; return false; }
      }
      @JavascriptInterface
      public String stopRec(){
        return stopRecInternal(true);
      }
      @JavascriptInterface
      public void cancelRec(){
        // если запись ещё стартует — пометим, чтобы startRec сам остановил; иначе останавливаем сейчас
        recStopRequested = true;
        stopRecInternal(false);
      }
      @JavascriptInterface
      public void vibrate(int ms){
        try{
          android.os.Vibrator v=(android.os.Vibrator)getSystemService(android.content.Context.VIBRATOR_SERVICE);
          if(v!=null&&v.hasVibrator()){
            if(android.os.Build.VERSION.SDK_INT>=26){ v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE)); }
            else { v.vibrate(ms); }
          }
        }catch(Exception e){}
      }
      @JavascriptInterface
      public void hideKeyboard(){
        try{
          runOnUiThread(() -> {
            try{
              android.view.View v = getCurrentFocus();
              if(v==null) v = bridge.getWebView();
              android.view.inputmethod.InputMethodManager imm=(android.view.inputmethod.InputMethodManager)getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
              if(imm!=null && v!=null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            }catch(Exception e){}
          });
        }catch(Exception e){}
      }
      @JavascriptInterface
      public void saveFileDialog(String name, String mime, String b64){
        try{
          pendingSaveBytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
          Intent it = new Intent(Intent.ACTION_CREATE_DOCUMENT);
          it.addCategory(Intent.CATEGORY_OPENABLE);
          it.setType(mime==null||mime.isEmpty()?"application/octet-stream":mime);
          it.putExtra(Intent.EXTRA_TITLE, name);
          try {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
              android.net.Uri initial = android.net.Uri.parse("content://com.android.externalstorage.documents/document/primary:Notenger");
              it.putExtra("android.provider.extra.INITIAL_URI", initial);
            }
          } catch(Exception e){}
          runOnUiThread(() -> { try { saveFileLauncher.launch(it); } catch(Exception e){} });
        }catch(Exception e){ pendingSaveBytes=null; }
      }
    }, "AndroidRec");
    // Мост авторизации Google для JS
    this.bridge.getWebView().addJavascriptInterface(new Object(){
      @JavascriptInterface
      public void getToken(final boolean interactive){
        runOnUiThread(() -> {
          try {
            GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            if (acct != null && GoogleSignIn.hasPermissions(acct, new Scope(DRIVE_SCOPE))) {
              fetchTokenAsync(acct);
            } else if (interactive) {
              signInLauncher.launch(gsiClient.getSignInIntent());
            } else {
              resolveToken(null);
            }
          } catch (Exception e) { resolveToken(null); }
        });
      }
      @JavascriptInterface
      public void signOut(){
        try { gsiClient.signOut(); } catch (Exception e) {}
      }
    }, "NotengerAuthNative");
    final android.app.Activity selfAct = this;
    this.bridge.getWebView().setWebChromeClient(new WebChromeClient() {
      @Override
      public void onPermissionRequest(final PermissionRequest request) {
        runOnUiThread(new Runnable() {
          @Override public void run() { request.grant(request.getResources()); }
        });
      }
      @Override
      public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> cb, FileChooserParams params) {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); }
        filePathCallback = cb;
        pendingCameraUri = null;
        boolean wantCapture = false;
        try { wantCapture = params.isCaptureEnabled(); } catch (Exception e) {}
        String acc = "";
        try { String[] types = params.getAcceptTypes(); if (types!=null) for (String t: types) if (t!=null) acc += t.toLowerCase()+","; } catch (Exception e) {}
        if (wantCapture) {
          try {
            boolean isVideo = acc.contains("video");
            java.io.File dir = new java.io.File(selfAct.getCacheDir(), "capture");
            dir.mkdirs();
            String ext = isVideo ? ".mp4" : ".jpg";
            java.io.File f = new java.io.File(dir, "cap_" + System.currentTimeMillis() + ext);
            Uri out = androidx.core.content.FileProvider.getUriForFile(selfAct, selfAct.getPackageName()+".fileprovider", f);
            pendingCameraUri = out;
            Intent cam = new Intent(isVideo ? android.provider.MediaStore.ACTION_VIDEO_CAPTURE : android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, out);
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (cam.resolveActivity(selfAct.getPackageManager()) != null) {
              fileChooserLauncher.launch(cam);
              return true;
            }
          } catch (Exception e) { pendingCameraUri = null; }
        }
        Intent intent = params.createIntent();
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { fileChooserLauncher.launch(intent); } catch (Exception e) { filePathCallback = null; return false; }
        return true;
      }
    });
    // Сохранение файлов (экспорт): ловим data:/blob: загрузки и пишем в папку Notenger
    final android.content.Context ctx = this;
    this.bridge.getWebView().setDownloadListener(new android.webkit.DownloadListener() {
      @Override
      public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
        try {
          String fileName = "notenger_backup.json";
          if (contentDisposition != null && contentDisposition.contains("filename=")) {
            fileName = contentDisposition.substring(contentDisposition.indexOf("filename=")+9).replace("\"","").trim();
          }
          byte[] bytes = null;
          if (url.startsWith("data:")) {
            int comma = url.indexOf(',');
            String meta = url.substring(0, comma);
            String dataPart = url.substring(comma+1);
            if (meta.contains("base64")) bytes = android.util.Base64.decode(dataPart, android.util.Base64.DEFAULT);
            else bytes = java.net.URLDecoder.decode(dataPart, "UTF-8").getBytes();
          }
          if (bytes == null) return;
          java.io.File dir = new java.io.File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "Notenger");
          if (!dir.exists()) dir.mkdirs();
          java.io.File out = new java.io.File(dir, fileName);
          java.io.FileOutputStream fos = new java.io.FileOutputStream(out);
          fos.write(bytes); fos.close();
          runOnUiThread(new Runnable(){ public void run(){ android.widget.Toast.makeText(ctx, "Сохранено: Download/Notenger/"+out.getName(), android.widget.Toast.LENGTH_LONG).show(); }});
        } catch (final Exception e) {
          runOnUiThread(new Runnable(){ public void run(){ android.widget.Toast.makeText(ctx, "Ошибка сохранения", android.widget.Toast.LENGTH_SHORT).show(); }});
        }
      }
    });
  }
  private String stopRecInternal(boolean wantData){
    String result = null;
    recActive = false;
    try{
      if(audioRec!=null){
        try{ audioRec.stop(); }catch(Exception ignore){}
        try{ audioRec.reset(); }catch(Exception ignore){}
        try{ audioRec.release(); }catch(Exception ignore){}
        audioRec=null;
        if(wantData && audioPath!=null){
          File f=new File(audioPath);
          if(f.exists() && f.length()>0){
            FileInputStream fis=new FileInputStream(f);
            byte[] data=new byte[(int)f.length()];
            fis.read(data); fis.close();
            result = "data:audio/mp4;base64," + Base64.encodeToString(data, Base64.NO_WRAP);
          }
        }
      }
    }catch(Exception e){ result=null; }
    try{ if(audioPath!=null){ new File(audioPath).delete(); } }catch(Exception ignore){}
    audioPath=null;
    return result;
  }
  private void fetchTokenAsync(final GoogleSignInAccount acct){
    new Thread(() -> {
      String token = null;
      try {
        Account a = acct.getAccount();
        token = GoogleAuthUtil.getToken(MainActivity.this, a, "oauth2:" + DRIVE_SCOPE);
      } catch (Exception e) { token = null; }
      resolveToken(token);
    }).start();
  }
  private void resolveToken(final String token){
    final String js;
    if (token != null) {
      js = "window.__ntgrResolveToken && window.__ntgrResolveToken(" + org.json.JSONObject.quote(token) + ");";
    } else {
      js = "window.__ntgrResolveToken && window.__ntgrResolveToken(null);";
    }
    runOnUiThread(() -> {
      try { this.bridge.getWebView().evaluateJavascript(js, null); } catch (Exception e) {}
    });
  }
  private void requestStartupPermissions() {
    ArrayList<String> need = new ArrayList<>();
    String[] perms;
    if (Build.VERSION.SDK_INT >= 33) {
      perms = new String[]{ Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
        Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO };
    } else {
      perms = new String[]{ Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,
        Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE };
    }
    for (String p : perms) {
      if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) need.add(p);
    }
    if (!need.isEmpty()) {
      ActivityCompat.requestPermissions(this, need.toArray(new String[0]), 1001);
    }
  }
}
