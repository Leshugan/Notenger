// Сборщик каталога БЕЗ САЙТА: списки тем и шапки берём по протоколу официального клиента 4pda
// (app.4pda.to:993). Ни Playwright, ни прокси, ни куки — обычный сокет.
import net from "net";
import zlib from "zlib";
import fs from "fs";

const HOST = "app.4pda.to", PORT = 993, CLIENT_VER = process.env.CLIENT_VER || "1.9.43";
const OUT = process.env.OUT || "catalog_proto.json";
const PER_FORUM = +(process.env.PER_FORUM || 3000);        // сколько тем брать из раздела
const MAX_MIN = +(process.env.MAX_MIN || 300);
const t0 = Date.now();
const overtime = () => (Date.now() - t0) / 60000 > MAX_MIN;

// ---- кадр протокола: 0x80|0x40|тип, длина, 4 байта исходной длины, raw-deflate
function frame(text) {
  const raw = Buffer.from(text, "binary");
  const packed = zlib.deflateRawSync(raw, { level: 6 });
  const lenField = packed.length + 4;
  const head = [];
  head.push(0xc1);
  if (lenField <= 0x7d) head.push(lenField);
  else if (lenField <= 0xffff) head.push(0x7e, (lenField >> 8) & 0xff, lenField & 0xff);
  else head.push(0x7f, 0, 0, 0, 0, (lenField >>> 24) & 0xff, (lenField >> 16) & 0xff, (lenField >> 8) & 0xff, lenField & 0xff);
  const orig = Buffer.alloc(4); orig.writeUInt32LE(raw.length, 0);
  return Buffer.concat([Buffer.from(head), orig, packed]);
}
function unframe(buf) {                                   // → [{num, text}], остаток
  const out = []; let i = 0;
  while (i + 2 <= buf.length) {
    const b0 = buf[i]; let ln = buf[i + 1] & 0x7f; let p = i + 2;
    if (ln === 126) { if (p + 2 > buf.length) break; ln = buf.readUInt16BE(p); p += 2; }
    else if (ln === 127) { if (p + 8 > buf.length) break; ln = Number(buf.readBigUInt64BE(p)); p += 8; }
    if (p + ln > buf.length) break;
    const pay = buf.subarray(p, p + ln); i = p + ln;
    let text = "";
    try { text = (b0 & 0x40) && ln > 4 ? zlib.inflateRawSync(pay.subarray(4)).toString("binary") : pay.toString("binary"); } catch { text = ""; }
    const c = text.indexOf(",");
    out.push({ num: text.startsWith("[") && c > 1 ? text.slice(1, c).trim() : "", text });
  }
  return [out, buf.subarray(i)];
}
const cp1251 = (s) => Buffer.from(s, "binary").toString("latin1");   // строки читаем как есть

class Proto {
  constructor() { this.sock = null; this.buf = Buffer.alloc(0); this.waiting = new Map(); this.num = 1000 + Math.floor(Math.random() * 90000); }
  connect() {
    return new Promise((res, rej) => {
      this.sock = net.connect({ host: HOST, port: PORT }, () => res());
      this.sock.on("data", (d) => {
        this.buf = Buffer.concat([this.buf, d]);
        const [frames, rest] = unframe(this.buf); this.buf = rest;
        for (const f of frames) { const w = this.waiting.get(f.num); if (w) { this.waiting.delete(f.num); w(f.text); } }
      });
      this.sock.on("error", rej);
      this.sock.setTimeout(60000, () => { try { this.sock.destroy(); } catch {} });
    });
  }
  ask(payload, timeout = 20000) {
    const n = this.num++;
    const body = "[" + n + "," + payload + "]";
    return new Promise((res) => {
      const t = setTimeout(() => { this.waiting.delete(String(n)); res(""); }, timeout);
      this.waiting.set(String(n), (txt) => { clearTimeout(t); res(txt); });
      try { this.sock.write(frame(body)); } catch { clearTimeout(t); res(""); }
    });
  }
  async hello() { await this.ask(`"ah","${CLIENT_VER}","","",0,0`); }
  close() { try { this.sock.destroy(); } catch {} }
}

// разделы каталога 4pda (как в старом сборщике)
const FORUMS = (process.env.FORUMS || "212,213,214,215,216,217,218,219,255,282,283,284,285,286").split(",").map((x) => x.trim()).filter(Boolean);

const db = (() => { try { return JSON.parse(fs.readFileSync(OUT, "utf8")); } catch { return { v: 1, updated: "", items: {} }; } })();
const save = (why) => { db.updated = new Date().toISOString(); fs.writeFileSync(OUT, JSON.stringify(db)); console.log(`сохранено (${why}): тем ${Object.keys(db.items).length}`); };
save("старт");

const p = new Proto();
await p.connect(); await p.hello();
console.log("подключено к серверу приложения");

let seen = 0;
for (const fid of FORUMS) {
  if (overtime()) break;
  for (let from = 0; from < PER_FORUM; from += 30) {
    if (overtime()) break;
    const txt = await p.ask(`"fs",${fid},${from},30`);
    if (!txt) break;
    const re = /\[(\d),(\d{3,9}),"((?:[^"\\]|\\.)*)"/g; let m; let got = 0;
    while ((m = re.exec(txt))) {
      const id = m[2];
      const title = cp1251(m[3]).replace(/\\u000[23]/g, "").replace(/\[\/?[a-z=#0-9]+\]/gi, "").trim();
      if (!title || title.length < 2) continue;
      got++;
      const prev = db.items[id] || {};
      db.items[id] = { ...prev, t: id, n: title, f: +fid };
    }
    if (!got) break;
    seen += got;
    if (seen % 300 < 30) save("по ходу");
  }
  console.log(`раздел ${fid}: всего собрано ${Object.keys(db.items).length}`);
}
save("итог");
p.close();
console.log("готово");
