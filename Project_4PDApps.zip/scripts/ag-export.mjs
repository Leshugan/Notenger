// Выгрузка каталога App&Game: категории по страницам → темы → файлы.
// Ничего не берёт из нашей базы: список тем строится из ответов их сервера.
import crypto from "crypto";
import fs from "fs";
const fsr = (p2) => { try { return fs.readFileSync(p2, "utf8"); } catch { return ""; } };
const fsw = (p2, v) => { try { fs.writeFileSync(p2, v); } catch {} };

const SRV = "https://srv1.freeman42.ru/app4pda.v3/";
const APP_VER = "5.3 beta 9 (539)";
const FB = process.env.FB_URL || "https://pdapps-e9cee-default-rtdb.europe-west1.firebasedatabase.app";
const BATCH = +(process.env.BATCH || 150);
let buf = [];
const PAUSE = +(process.env.PAUSE_MS || 60);   // по одной теме на запрос, но тем много — пауза поменьше
const GROUPS = +(process.env.GROUPS || 40);        // сколько номеров категорий перебрать
const TOPICS_PER_ASK = 1;                          // РОВНО одна тема на запрос — как ag4pda (fragments/h). Через «|» сервер отдавал только первую → терялось ~7/8 тем

const rawId = process.env.AG_DEVICE_ID || "t4pdapps-robot-0001";
const key = Buffer.from(rawId, "utf8").toString("base64").split("").reverse().join("");
const hash = crypto.createHash("md5").update(rawId).digest("hex");
const auth = `key=${encodeURIComponent(key)}&hash=${hash}&app_ver=${encodeURIComponent(APP_VER)}`;
console.log("версия робота: пишем прямо в базу (v4)");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function ask(method, q) {
  for (let t = 0; t < 3; t++) {
    try {
      const r = await fetch(`${SRV}${method}?${auth}&${q}`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "device_info=robot",
      });
      return JSON.parse(await r.text());
    } catch { await sleep(500 * (t + 1)); }
  }
  return null;
}

async function flush() {                                   // отправляем накопленное одной пачкой
  if (!buf.length) return 0;
  const part = buf; buf = [];
  for (let t = 0; t < 3; t++) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), 20000);
    try {
      const body = {};
      for (const x of part) body[String(x.aid)] = x;             // ключ — номер вложения, повтор просто перезапишется
      const r = await fetch(`${FB}/files.json`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: ac.signal });
      clearTimeout(timer);
      if (r.ok) return part.length;
      const txt = await r.text().catch(() => "");
      console.log(`пачка не принята: код ${r.status} · ${txt.slice(0, 200)}`);
      if (r.status === 429 || r.status >= 500) { await sleep(3000); continue; }
      return 0;
    } catch (e) { clearTimeout(timer); console.log("пачка не ушла:", e && e.message); await sleep(1500); }
  }
  return 0;
}
async function send(rec) {
  for (let t = 0; t < 2; t++) {
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), 12000);       // не ждём вечно
    try {
      const r = await fetch(SINK, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(rec), signal: ac.signal });
      clearTimeout(timer);
      if (r.ok) return true;
      if (r.status === 429) { await sleep(2000); continue; }  // приёмник просит подождать
      return false;
    } catch { clearTimeout(timer); await sleep(1000); }
  }
  return false;
}

const STATE = "ag-export-state.json";
const topics = new Set();
let cards = 0, files = 0, sent = 0;
const PER_RUN = +(process.env.PER_RUN || 60000);   // за один прогон — весь каталог (~50к тем ≈ 4ч, влезает в лимит 350мин); при обрыве курсор в базе продолжит

// ПОЛНЫЙ список тем — из каталога репозитория (в нём ВСЕ темы 4pda, а не только 40 категорий).
// Именно это делает нашу базу полной: getFileInfo зовём по КАЖДОЙ теме с приложением.
let catTopics = [];
try {
  const cj = JSON.parse(fsr("catalog.json") || "{}");
  const apps = Array.isArray(cj.apps) ? cj.apps : [];
  const seen = new Set();
  for (const a of apps) { const t = String(a.t || a.topicId || ""); if (t && !seen.has(t)) { seen.add(t); catTopics.push(t); } }
  console.log(`каталог: тем ${catTopics.length}`);
} catch (e) { console.log("каталог не прочитан:", e && e.message); }

// 1) лёгкий проход по категориям — ТОЛЬКО ради связей пакет→тема+версия (для проверки обновлений без сервера)
for (let g = 1; g <= GROUPS; g++) {
  let page = 0, total = 0;
  do {
    const o = await ask("getAppInfo.php", `group_id=${g}&page=${page}`);
    const arr = (o && o.data) || [];
    for (const m of ((o && o.meta) || [])) if (m && m.found_rows) total = +m.found_rows;
    if (!arr.length) break;
    for (const x of arr) { if (x.topic_id) topics.add(String(x.topic_id)); cards++; }
    try {                                                   // связи из их каталога — в наш общий список
      const links = arr.filter((x) => x.pack_name && x.topic_id)
        .map((x) => ({ pkg: String(x.pack_name), topicId: +x.topic_id, title: String(x.name || ""), ver: String(x.ver || ""), upd: String(x.forum_update || "") }));
      if (links.length) {
        const ac = new AbortController();
        const tm = setTimeout(() => ac.abort(), 20000);
        const body2 = {};
        for (const l of links) body2[l.pkg.replace(/\./g, "_")] = { topicId: l.topicId, title: l.title, ...(l.ver ? { ver: l.ver } : {}), ...(l.upd ? { upd: l.upd } : {}) };   // версия и дата с их сервера — телефону для проверки без сервера
        await fetch(`${FB}/links.json`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body2), signal: ac.signal });
        clearTimeout(tm);
      }
    } catch {}
    console.log(`категория ${g}, страница ${page}: ${arr.length} шт (всего ${total})`);
    page++;
    await sleep(PAUSE);
  } while (page * 100 < total && page < 60);
}
console.log(`карточек: ${cards}`);

// 2) файлы по ВСЕМ темам каталога — по одной теме на запрос (как ag4pda), курсор в состоянии, порция за прогон
const list = catTopics.length ? catTopics : [...topics];
let start = 0;
try { const rc = await fetch(`${FB}/meta/ag_cursor.json`); const t = await rc.text(); start = +(JSON.parse(t || "0") || 0); } catch {}   // курсор в базе — переживает перезапуски прогонов (артефакт GitHub не скачивался)
if (!(start >= 0) || start >= list.length) start = 0;
const end = Math.min(list.length, start + PER_RUN);
console.log(`файлы: темы ${start}..${end} из ${list.length}`);
for (let i = start; i < end; i += TOPICS_PER_ASK) {
  const tid = list[i];
  const o = await ask("getFileInfo.php", `topic_id=${tid}`);   // РОВНО одна тема (сервер игнорирует «|», брал только первую)
  const recs = {};
  for (const x of ((o && o.data) || [])) {
    const url = String(x.file_name || "");
    const aid = +(((url.match(/\/dl\/post\/(\d+)\//) || [])[1]) || 0);
    if (!aid || !x.pack_name) continue;   // подпись бывает пустой у некоторых сборок — запись всё равно ценна (пакет/версия/crc/флаги)
    files++;
    recs[String(aid)] = {
      topicId: +(x.topic_id || 0) || +tid, aid, url, name: url.split("/").pop(),
      app_name: x.app_name || "", pkg: x.pack_name, ver: x.version_name || "",
      code: +(x.version_code || 0), sig: x.signature || "", minSdk: +(x.min_sdk || 0),
      abis: "", size: +(x.file_size || 0), crc32: x.crc32 || "",
    };
  }
  if (Object.keys(recs).length) {                             // файлы темы — одним узлом: телефон заберёт их одним маленьким запросом
    for (let t = 0; t < 3; t++) {
      const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), 20000);
      try {
        const r = await fetch(`${FB}/tfiles/${tid}.json`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(recs), signal: ac.signal });
        clearTimeout(tm);
        if (r.ok) { sent += Object.keys(recs).length; break; }
        if (r.status === 429 || r.status >= 500) { await sleep(2000); continue; }
        break;
      } catch { clearTimeout(tm); await sleep(1000); }
    }
  }
  if (i % 80 === 0) {
    console.log(`темы ${i}/${end} (всего ${list.length}) · файлов ${files} · отправлено ${sent}`);
    try { await fetch(`${FB}/meta/ag_cursor.json`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: String(i) }); } catch {}
  }
  await sleep(PAUSE);
}
const next = end >= list.length ? 0 : end;                 // дошли до конца — курсор в начало (следующий прогон обновит всё заново)
try { await fetch(`${FB}/meta/ag_cursor.json`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: String(next) }); } catch {}
console.log(`ГОТОВО: файлов ${files}, отправлено ${sent}, курсор -> ${next}${next ? " (нужен ещё прогон)" : " (каталог пройден полностью)"}`);

