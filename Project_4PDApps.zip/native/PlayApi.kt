package leshugan.a4pda

import android.content.Context
import com.aurora.gplayapi.data.models.AuthData
import com.aurora.gplayapi.helpers.AppDetailsHelper
import com.google.gson.Gson
import okhttp3.Cache
import java.io.File

object PlayApi {
    private const val AUTH_URL = "https://auroraoss.com/api/auth"
    private const val PREFS = "t4play"
    private const val K_AUTH = "authData"
    private const val K_PROFILE = "profileVersion"
    private const val K_CHECK = "lastCheck"
    private const val PROFILE_VERSION = 1
    private const val CHECK_MS = 60L * 60L * 1000L      // раз в час проверяем, жив ли сохранённый токен

    @Volatile
    private var cachedAuth: AuthData? = null

    private fun client(context: Context) =
        PlayHttpClient(Cache(File(context.cacheDir, "playcache"), 2L * 1024 * 1024))

    // Версия одного приложения. null при любой ошибке.
    @JvmStatic
    fun version(context: Context, pkg: String): String? {
        return try {
            val gson = Gson()
            val c = client(context)
            val app = AppDetailsHelper(auth(context, gson, c)).using(c).getAppByPackageName(pkg)
            val v = app.versionName
            if (v.isNullOrEmpty()) null else v + "\u0001" + app.versionCode
        } catch (e: Throwable) {
            null
        }
    }

    // Версии ПАЧКОЙ (как в APKUpdater): один запрос на список пакетов вместо запроса на каждый.
    // Возвращает строки "pkg\u0001versionName\u0001versionCode"; отсутствующие в Play просто не попадают в ответ.
    @JvmStatic
    fun versions(context: Context, pkgs: List<String>): List<String> {   // не больше 20 пакетов за вызов (лимит gplayapi)
        return try {
            val gson = Gson()
            val c = client(context)
            AppDetailsHelper(auth(context, gson, c)).using(c).getAppByPackageName(pkgs)
                .filter { !it.packageName.isNullOrEmpty() && !it.versionName.isNullOrEmpty() }
                .map { it.packageName + "\u0001" + it.versionName + "\u0001" + it.versionCode }
        } catch (e: Throwable) {
            emptyList()
        }
    }

    // Анонимная сессия Play. Токен ХРАНИТСЯ НА ДИСКЕ и переживает перезапуск —
    // раздатчик auroraoss дёргаем только когда токена нет, он протух или сменился профиль устройства.
    private fun auth(context: Context, gson: Gson, client: PlayHttpClient): AuthData {
        cachedAuth?.let { return it }
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = sp.getString(K_AUTH, "") ?: ""
        if (raw.isNotEmpty() && sp.getInt(K_PROFILE, 0) == PROFILE_VERSION) {
            val saved = try { gson.fromJson(raw, AuthData::class.java) } catch (e: Throwable) { null }
            if (saved != null && !saved.email.isNullOrEmpty()) {
                val now = System.currentTimeMillis()
                if (now - sp.getLong(K_CHECK, 0L) <= CHECK_MS) { cachedAuth = saved; return saved }
                // раз в час — лёгкая проверка живости токена одним запросом
                val ok = try {
                    AppDetailsHelper(saved).using(client)
                        .getAppByPackageName("com.google.android.gm").packageName.isNotEmpty()
                } catch (e: Throwable) { false }
                if (ok) {
                    sp.edit().putLong(K_CHECK, now).apply()
                    cachedAuth = saved
                    return saved
                }
            }
        }
        return refresh(context, gson, client)
    }

    private fun refresh(context: Context, gson: Gson, client: PlayHttpClient): AuthData {
        val props = NativeDeviceInfoProvider(context).getNativeDeviceProperties()
        val resp = client.postAuth(AUTH_URL, gson.toJson(props).toByteArray())
        if (!resp.isSuccessful) throw IllegalStateException("auth ${resp.code}")
        val data = gson.fromJson(String(resp.responseBytes), AuthData::class.java)
        cachedAuth = data
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(K_AUTH, gson.toJson(data))
                .putInt(K_PROFILE, PROFILE_VERSION)
                .putLong(K_CHECK, System.currentTimeMillis())
                .apply()
        } catch (e: Throwable) {}
        return data
    }

    // ВНИМАНИЕ: в gplayapi 3.5.8 AuthData.locale — val, присваивание не компилируется (на этом падала сборка AW)
}
